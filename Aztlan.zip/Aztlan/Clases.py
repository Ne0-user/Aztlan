class Ser_Vivo:
    def __init__(self, edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY):
        self.vida = 100
        self.defensa = 0
        self.salud = 100
        self.energia = 100
        self.hambre = 100
        self.sed = 100
        self.felicidad = 100
        self.edad = edad
        self.nombre = nombre
        self.fuerza = fuerza
        self.resistencia = resistencia
        self.velocidad = velocidad
        self.posicionX = posicionX
        self.posicionY = posicionY
    
    def comer(self):
        pass
    def dormir(self):
        pass
    def beber(self):
        pass
    def morir(self):
        pass
        

class __Habilidades:#proposito struct
        def __init__(self):
            self.mineria = 10
            self.carpinteria = 10
            self.construccion = 10
            self.agricultura = 10
            self.cocina = 10
            self.combate = 10
#-----------------------------------------------------fin de clase Habilidades  
        
#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------

class Animal(Ser_Vivo):
    def __init__(self, edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY):
        super().__init__(edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY)
        
#-----------------------------------------------------fin de clase Animal
class Vaca(Animal):
    def __init__(self, edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY):
        super().__init__(edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY)
#-----------------------------------------------------fin de clase Vaca
class Pollo(Animal):
    def __init__(self, edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY):
        super().__init__(edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY)
#-----------------------------------------------------fin de clase Pollo

#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------

class Material:
    def __init__(self):
        self.usos = None
#-----------------------------------------------------fin de clase Material
class Piedra(Material):
    def __init__(self):
        super().__init__()
        self.usos = 3
#-----------------------------------------------------fin de clase Piedra
class Agua(Material):
    def __init__(self):
        super().__init__()
#-----------------------------------------------------fin de clase Agua
class Arbol(Material):
    def __init__(self):
        super().__init__()
        self.usos = 20
#-----------------------------------------------------fin de clase Arbol
class Tierra(Material):
    def __init__(self):
        super().__init__()
#-----------------------------------------------------fin de clase Tierra

#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------


        
        
        
        
        
        
        
        
        
        
        