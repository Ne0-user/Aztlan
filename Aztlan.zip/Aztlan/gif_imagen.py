from PIL import Image
import os

def gif_a_imagenes(ruta_gif, carpeta_salida):
    """
    Convierte un archivo GIF animado en una secuencia de imágenes.

    Args:
        ruta_gif (str): La ruta al archivo GIF de entrada.
        carpeta_salida (str): La carpeta donde se guardarán los fotogramas.
    """
    
    # Asegúrate de que la carpeta de salida exista
    if not os.path.exists(carpeta_salida):
        os.makedirs(carpeta_salida)

    try:
        # Abre el archivo GIF
        img = Image.open(ruta_gif)
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo en la ruta {ruta_gif}")
        return
    
    print(f"Abriendo el GIF: {ruta_gif}")
    
    # Recorre cada fotograma del GIF
    for i in range(img.n_frames):
        # Selecciona el fotograma actual
        img.seek(i)
        
        # Guarda el fotograma como un archivo PNG
        nombre_archivo = os.path.join(carpeta_salida, f"base_Left_{i+1}.png")
        
        # Convierte el fotograma a RGBA para manejar la transparencia correctamente
        img.save(nombre_archivo, "PNG")
        print(f"Guardando {nombre_archivo}...")

    print("Extracción completada.")


# --- Uso del script ---
if __name__ == "__main__":
    # Define la ruta del archivo GIF y la carpeta de salida
    ruta_del_gif = "animacion.gif"  # Reemplaza con la ruta de tu archivo
    carpeta_de_salida = "fotogramas_extraidos"
    
    gif_a_imagenes("C:/Users/aldo/Desktop/Aztlan/sprites/Zombie_Left/basez_Left.gif", "C:/Users/aldo/Desktop/Aztlan/sprites/Zombie_Left")