from Humano import Humano

class Zombie(Humano):
    def __init__(self, edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY, inventario, linaje, profesion, estatus, bendicion):
        super().__init__(edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY, inventario, linaje, profesion, estatus, bendicion)
#-----------------------------------------------------fin de clase Zombie
class Bruja(Zombie):
    def __init__(self, edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY, inventario, linaje, profesion, estatus, bendicion):
        super().__init__(edad, nombre, genero, fuerza, resistencia, velocidad, posicionX, posicionY, inventario, linaje, profesion, estatus, bendicion)