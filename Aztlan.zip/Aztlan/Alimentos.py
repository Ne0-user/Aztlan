#aqui separe los tipos de comida en cruda y cocinada, fue para los metodos de humano
#como recolectar comida y cazar. puedes editar las clases pero no borrarlas

class Comida_cocinada:
    def __init__(self):
        self.saciar = 20
        self.imagen = "sprites/comida_cocinada.png"
        self.cantidad = 0
#-----------------------------------------------------fin de clase Carne
class Comida_cruda:
    def __init__(self):
        self.saciar = 4
        self.imagen = "sprites/comida_cruda.png"
        self.cantidad = 0
class Agua_bebida:
    def __init__(self):
        self.hidratar = 15
        self.imagen = "sprites/Agua_bebida.png"
        self.cantidad = 0