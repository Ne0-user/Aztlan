class Material:
    def __init__(self):
        self.usos = None
#-----------------------------------------------------fin de clase Material
class Piedra(Material):
    def __init__(self):
        super().__init__()
        self.usos = 3
#-----------------------------------------------------fin de clase Piedra
class Agua(Material):
    def __init__(self):
        super().__init__()
#-----------------------------------------------------fin de clase Agua
class Arbol(Material):
    def __init__(self):
        super().__init__()
        self.usos = 20
#-----------------------------------------------------fin de clase Arbol
class Tierra(Material):
    def __init__(self):
        super().__init__()
#-----------------------------------------------------fin de clase Tierra